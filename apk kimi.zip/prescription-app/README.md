# MediCare Pro - تطبيق إدارة الوصفات الطبية

تطبيق Android احترافي لإدارة الوصفات الطبية مع قاعدة بيانات SQLite محلية.

## 📱 المميزات

- ✅ **إنشاء وصفات طبية** - واجهة سهلة لإنشاء وصفات جديدة
- ✅ **قاعدة بيانات محلية** - SQLite لتخزين البيانات على الجهاز
- ✅ **بحث وتصفية** - البحث في الوصفات حسب الاسم والحالة
- ✅ **طباعة الوصفات** - طباعة مباشرة من التطبيق
- ✅ **تخصيص كامل** - تغيير اسم المستشفى، الشعار، والألوان
- ✅ **دعم اللغتين** - عربي وإنجليزي
- ✅ **واجهة متجاوبة** - تعمل على جميع أحجام الشاشات

## 🗄️ جداول قاعدة البيانات

```sql
-- جدول الوصفات
prescriptions:
  - id (INTEGER PRIMARY KEY)
  - patient_name (TEXT)
  - patient_age (TEXT)
  - file_number (TEXT)
  - doctor_name (TEXT)
  - diagnosis (TEXT)
  - instructions (TEXT)
  - status (TEXT: pending/completed/cancelled)
  - date (TEXT)
  - created_at (DATETIME)

-- جدول الأدوية
medications:
  - id (INTEGER PRIMARY KEY)
  - prescription_id (INTEGER)
  - name (TEXT)
  - dose (TEXT)
  - frequency (TEXT)
  - duration (TEXT)
  - route (TEXT)

-- جدول الإعدادات
settings:
  - key (TEXT PRIMARY KEY)
  - value (TEXT)
```

## 🚀 خطوات البناء

### المتطلبات

- Node.js (v16 أو أحدث)
- Android Studio
- Android SDK
- JDK 11 أو أحدث

### 1. تثبيت Capacitor CLI

```bash
npm install -g @capacitor/cli
```

### 2. تثبيت التبعيات

```bash
cd prescription-app
npm install
```

### 3. إضافة منصة Android

```bash
npx cap add android
```

### 4. تثبيت إضافة SQLite

```bash
npm install @capacitor-community/sqlite
npx cap sync
```

### 5. بناء التطبيق

```bash
# Debug build
npx cap build android

# أو فتح في Android Studio
npx cap open android
```

### 6. إنشاء ملف APK

في Android Studio:
1. Build → Build Bundle(s) / APK(s) → Build APK(s)
2. أو Build → Generate Signed Bundle / APK

## 📦 ملف APK الناتج

بعد البناء بنجاح، ستجد ملف APK في:

```
android/app/build/outputs/apk/debug/app-debug.apk
```

أو للنسخة الموقعة:

```
android/app/build/outputs/apk/release/app-release.apk
```

## 📁 هيكل المشروع

```
prescription-app/
├── www/                      # ملفات الويب
│   ├── index.html           # الواجهة الرئيسية
│   ├── app.js               # منطق التطبيق
│   └── res/                 # الموارد
│       ├── icon/android/    # أيقونات التطبيق
│       └── screen/android/  # شاشات البداية
├── capacitor.config.json    # إعدادات Capacitor
├── package.json             # تبعيات المشروع
└── README.md                # هذا الملف
```

## 🔧 التخصيص

### تغيير معرف التطبيق

في `capacitor.config.json`:

```json
{
  "appId": "com.yourcompany.prescriptions",
  "appName": "Your App Name"
}
```

### تغيير الأيقونة والشعار

استبدل الملفات في:
- `www/res/icon/android/` - الأيقونات
- `www/res/screen/android/` - شاشات البداية

### تغيير الألوان

في `www/index.html`، عدل متغيرات CSS:

```css
:root {
  --primary: #0891b2;        /* اللون الرئيسي */
  --secondary: #10b981;      /* اللون الثانوي */
  --danger: #ef4444;         /* لون الخطر */
  --warning: #f59e0b;        /* لون التحذير */
}
```

## 📱 الاستخدام

### إنشاء وصفة جديدة

1. اضغط على "وصفة جديدة"
2. أدخل بيانات المريض
3. أضف الأدوية المطلوبة
4. اضغط "حفظ الوصفة"

### عرض الوصفات

- قائمة الوصفات: عرض جميع الوصفات مع إمكانية البحث
- الأرشيف: عرض الوصفات في بطاقات منفصلة

### طباعة الوصفة

1. افتح الوصفة المطلوبة
2. اضغط على زر الطباعة
3. اختر الطابعة

### الإعدادات

1. اضغط على "الإعدادات"
2. عدل اسم المستشفى والمعلومات
3. اختر الشعار واللون
4. احفظ الإعدادات

## 🛠️ استكشاف الأخطاء

### مشكلة: التطبيق لا يعمل

```bash
# تنظيف وإعادة البناء
npx cap clean
npx cap sync
npx cap build android
```

### مشكلة: قاعدة البيانات لا تعمل

- تأكد من تثبيت إضافة SQLite
- تحقق من صلاحيات التطبيق
- راجع سجلات الأخطاء في Android Studio

### مشكلة: البناء يفشل

```bash
# تحديث التبعيات
npm update
npx cap sync

# أو حذف node_modules وإعادة التثبيت
rm -rf node_modules
npm install
```

## 📄 الترخيص

MIT License - حر في الاستخدام والتعديل

## 🤝 المساهمة

نرحب بمساهماتكم! يمكنكم:
- الإبلاغ عن الأخطاء
- اقتراح ميزات جديدة
- إرسال طلبات pull

## 📞 الدعم

للاستفسارات والدعم:
- البريد: support@medicare.com
- الموقع: https://medicare.com
