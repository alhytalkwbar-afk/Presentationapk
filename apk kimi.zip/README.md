# MediCare Pro - تطبيق إدارة الوصفات الطبية

![MediCare Pro](prescription-app/www/res/icon/android/xhdpi.png)

تطبيق Android احترافي لإدارة الوصفات الطبية مع قاعدة بيانات SQLite محلية.

## 📱 المميزات الرئيسية

| الميزة | الوصف |
|--------|-------|
| 💊 **إنشاء وصفات** | واجهة سهلة لإنشاء وصفات طبية جديدة |
| 💾 **تخزين محلي** | SQLite لتخزين البيانات على الجهاز |
| 🔍 **بحث متقدم** | البحث والتصفية حسب الاسم والحالة |
| 🖨️ **طباعة** | طباعة الوصفات مباشرة |
| 🎨 **تخصيص** | تغيير اسم المستشفى والشعار والألوان |
| 🌐 **ثنائي اللغة** | دعم العربية والإنجليزية |
| 📱 **متجاوب** | يعمل على جميع أحجام الشاشات |

## 📦 محتويات الملف المضغوط

```
MediCare-Pro-Source.tar.gz
├── prescription-app/          # مجلد المشروع
│   ├── www/                   # ملفات الويب
│   │   ├── index.html         # الواجهة الرئيسية
│   │   ├── app.js             # منطق التطبيق
│   │   ├── manifest.json      # إعدادات PWA
│   │   └── res/               # الموارد (أيقونات وصور)
│   ├── capacitor.config.json  # إعدادات Capacitor
│   ├── package.json           # تبعيات npm
│   ├── build.sh               # سكربت بناء (Linux/Mac)
│   ├── build.bat              # سكربت بناء (Windows)
│   └── README.md              # توثيق المشروع
└── BUILD-GUIDE.md             # دليل البناء الشامل
```

## 🚀 كيفية البناء

### المتطلبات

- [Node.js](https://nodejs.org/) (v16+)
- [Android Studio](https://developer.android.com/studio)
- Android SDK

### خطوات سريعة

#### 1. استخراج الملفات
```bash
tar -xzf MediCare-Pro-Source.tar.gz
cd prescription-app
```

#### 2. تشغيل سكربت البناء

**Windows:**
```cmd
build.bat
```

**Linux/Mac:**
```bash
chmod +x build.sh
./build.sh
```

#### 3. فتح في Android Studio
```bash
npx cap open android
```

#### 4. بناء APK
في Android Studio:
- **Build → Build Bundle(s) / APK(s) → Build APK(s)**

## 📁 موقع ملف APK

بعد البناء:
```
android/app/build/outputs/apk/debug/app-debug.apk
```

## 🗄️ قاعدة البيانات

### الجداول

**prescriptions** - تخزين الوصفات
```sql
id, patient_name, patient_age, file_number,
doctor_name, diagnosis, instructions,
status, date, created_at
```

**medications** - تخزين الأدوية
```sql
id, prescription_id, name, dose,
frequency, duration, route
```

**settings** - إعدادات التطبيق
```sql
key, value
```

## 🎨 تخصيص التطبيق

### تغيير الألوان

في `www/index.html`:
```css
:root {
  --primary: #0891b2;      /* اللون الرئيسي */
  --secondary: #10b981;    /* اللون الثانوي */
  --danger: #ef4444;       /* لون الخطر */
  --warning: #f59e0b;      /* لون التحذير */
}
```

### تغيير الأيقونة

استبدل الملفات في:
```
www/res/icon/android/
```

### تغيير اسم التطبيق

في `capacitor.config.json`:
```json
{
  "appId": "com.yourcompany.prescriptions",
  "appName": "Your App Name"
}
```

## 📱 الاستخدام

### إنشاء وصفة جديدة

1. اضغط على "وصفة جديدة"
2. أدخل بيانات المريض
3. أضف الأدوية
4. اضغط "حفظ الوصفة"

### عرض الوصفات

- **القائمة**: عرض جميع الوصفات
- **الأرشيف**: عرض في بطاقات منفصلة

### طباعة وصفة

1. افتح الوصفة
2. اضغط زر الطباعة 🖨️

### الإعدادات

1. اذهب إلى "الإعدادات"
2. عدل:
   - اسم المستشفى
   - معلومات الاتصال
   - الشعار
   - اللون

## 🛠️ استكشاف الأخطاء

### مشكلة: التطبيق لا يعمل

```bash
# تنظيف وإعادة البناء
npx cap clean
npx cap sync
npx cap build android
```

### مشكلة: قاعدة البيانات لا تعمل

```bash
# إعادة تثبيت SQLite
npm install @capacitor-community/sqlite
npx cap sync
```

### مشكلة: البناء يفشل

```bash
# تحديث التبعيات
rm -rf node_modules
npm install
npx cap sync
```

## 📚 دليل شامل

للحصول على دليل بناء مفصل، راجع:
- **[BUILD-GUIDE.md](BUILD-GUIDE.md)** - دليل البناء الشامل

## 🌟 المميزات القادمة

- [ ] مزامنة مع السحابة
- [ ] نسخ احتياطي/استعادة
- [ ] إحصائيات متقدمة
- [ ] تصدير PDF
- [ ] تذكير بالأدوية

## 📄 الترخيص

MIT License - حر في الاستخدام والتعديل

## 🤝 المساهمة

نرحب بمساهماتكم!
- الإبلاغ عن الأخطاء
- اقتراح ميزات
- تحسين الكود

---

**تم التطوير بـ ❤️ لخدمة المجال الطبي**
